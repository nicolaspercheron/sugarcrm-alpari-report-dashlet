<?php

$manifest = array (
	'acceptable_sugar_versions' => array(),
	'acceptable_sugar_flavors' => array(),
	'name' => 'AlpariReportDashlet',
	'description' => 'The Dashlet displays the results of a report',
	'author' => 'Alpari',
	'published_date' => '2013-05-20 13:49:58',
	'version' => '0.1',
	'type' => 'module',
	'icon' => '',
	'is_uninstallable' => true,
);

$installdefs = array( 
	'id' => 'AlpariReportDashlet', 
	'copy' => array(
		array('from'=> '<basepath>/modules/Reports/Dashlets/AlpariReportDashlet/',
			  'to'=> 'custom/modules/Reports/Dashlets/AlpariReportDashlet',
		),
	),
	'post_execute'=>array(
		0 => '<basepath>/post_install/install_actions.php',
	),
	'post_uninstall'=>array(
		0 => '<basepath>/post_uninstall/uninstall_actions.php',
	)
);

?>

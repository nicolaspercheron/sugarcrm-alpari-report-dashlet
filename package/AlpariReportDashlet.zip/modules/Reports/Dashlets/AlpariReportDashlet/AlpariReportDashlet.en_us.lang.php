<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$dashletStrings['AlpariReportDashlet'] = array(
    'LBL_TITLE' => 'Alpari Report Dashlet',
    'LBL_DESCRIPTION' => 'This dashlet can display the results of the report',
    'LBL_OPT_LABEL' => 'General',
    'LBL_OPT_REPORT_LABEL' => 'Report',
    'LBL_OPT_LIMIT_LABEL' => 'Limit',
    'LBL_NO_DATA' => 'No data',
    'LBL_NO_REPORT' => 'Select the report',
    'LBL_RETRIEVE_ERROR' => 'Can\'t get the results of the report',
    'LBL_SAVE_BUTTON_LABEL' => 'Save'
);
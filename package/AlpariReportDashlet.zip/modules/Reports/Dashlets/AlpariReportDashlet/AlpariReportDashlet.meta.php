<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

global $app_strings, $current_language;

$dashletMeta['AlpariReportDashlet'] = array(
    'title' => 'LBL_TITLE',
    'description' => 'LBL_DESCRIPTION',
	'icon' => 'custom/modules/Reports/Dashlets/AlpariReportDashlet/AlpariReportDashlet.icon.png',
    'category' => 'Tools');